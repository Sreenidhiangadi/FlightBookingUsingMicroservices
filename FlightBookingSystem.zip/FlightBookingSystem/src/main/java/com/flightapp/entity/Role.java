package com.flightapp.entity;

public enum Role {
USER,ADMIN
}

