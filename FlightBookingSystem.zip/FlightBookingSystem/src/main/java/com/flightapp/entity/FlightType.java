package com.flightapp.entity;

public enum FlightType {
	ONE_WAY,
    ROUND_TRIP
}
